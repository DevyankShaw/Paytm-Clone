package com.example.devyankshaw.paytmclone;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
//    BottomNavigationView bottomNavigationView;
//    ViewPager viewPager;
//    MenuItem prevMenuItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(this);


        loadFragment(new HomeFragment());


//        bottomNavigationView = findViewById(R.id.navigation);
//        viewPager = findViewById(R.id.viewpager);
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch (item.getItemId()) {
//                    case R.id.navigation_home:
//                        viewPager.setCurrentItem(0);
//                        break;
//                    case R.id.navigation_mall:
//                        viewPager.setCurrentItem(1);
//                        break;
//                    case R.id.navigation_scan:
//                        viewPager.setCurrentItem(2);
//                        break;
//                    case R.id.navigation_bank:
//                        viewPager.setCurrentItem(3);
//                        break;
//                    case R.id.navigation_inbox:
//                        viewPager.setCurrentItem(4);
//                        break;
//                }
//
//                return false;
//            }
//        });
//        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//                if (prevMenuItem != null) {
//                    prevMenuItem.setChecked(false);
//                } else {
//                    bottomNavigationView.getMenu().getItem(0).setChecked(false);
//                }
//                Log.d("page", "onPageSelected: " + position);
//                bottomNavigationView.getMenu().getItem(position).setChecked(true);
//                prevMenuItem = bottomNavigationView.getMenu().getItem(position);
//
//            }
//
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//        });
//        setupViewPager(viewPager);
//
//    }
//
//    private void setupViewPager(ViewPager viewPager) {
//        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
//        viewPagerAdapter.addFragment(new HomeFragment());
//        viewPagerAdapter.addFragment(new MallFragment());
//        viewPagerAdapter.addFragment(new ScanFragment());
//        viewPagerAdapter.addFragment(new BankFragment());
//        viewPagerAdapter.addFragment(new InboxFragment());
//        viewPager.setAdapter(viewPagerAdapter);
//    }
    }

    private boolean loadFragment(Fragment fragment){

        if(fragment != null){

            getSupportFragmentManager().
                    beginTransaction().
                    replace(R.id.fragment_container, fragment).
                    commit();


            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        Fragment fragment = null;

        switch (menuItem.getItemId()){
            case R.id.navigation_home:
                 fragment = new HomeFragment();
                 break;

            case R.id.navigation_mall:
                fragment = new MallFragment();
                break;

            case R.id.navigation_scan:
                fragment = new ScanFragment();
                break;

            case R.id.navigation_bank:
                fragment = new BankFragment();
                break;

            case R.id.navigation_inbox:
                fragment = new InboxFragment();
                break;

        }
        return loadFragment(fragment);
    }

}
